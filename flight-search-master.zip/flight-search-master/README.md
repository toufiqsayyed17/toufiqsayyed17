Flight-search
=============
A sample client side application to implement flight search

### Todo

* Add form validations
* Date-Time calculation
* Improve UI, client side templating
* Improve JS code for modularity, remove global variables

### Plugins used

* [Bootstrap] (http://getbootstrap.com/)
* [Underscore] (http://underscorejs.org)
* [Select2] (http://ivaynberg.github.io/select2/)
* [DateTime Picker] (http://xdsoft.net/jqplugins/datetimepicker/)
* [Linq] (http://linqjs.codeplex.com/)
* [DateJS] (http://www.datejs.com/)
